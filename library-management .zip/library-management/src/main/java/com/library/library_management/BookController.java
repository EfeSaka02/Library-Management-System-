package com.library.library_management;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    @GetMapping("/")
    public String viewHomePage(Model model) {
        model.addAttribute("listBooks",bookService.listAll());
        return "index";
    }

    @GetMapping("/new")
    public String showNewBookForm(Model model) {
        Book book = new Book();
        model.addAttribute("book",book);
        return "new_book";
    }

    @PostMapping("/save")

    public String saveBook(@ModelAttribute("book")Book book) {
        bookService.saveBook(book);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
       public String showEditBookForm(@PathVariable("id") Long id, Model model) {
        Book book = bookService.getBookById(id);
        model.addAttribute("book",book);
        return "edit_book";
    }

    @GetMapping("/delete/{id}")

    public String deleteBook(@PathVariable("id") Long id) {
        bookService.deleteBookById(id);
        return "redirect:/";
    }

    @GetMapping("/search")

    public String search(@RequestParam("keyword" ) String keyword, Model model) {
          List<Book> result = bookService.searchBooks(keyword);
          model.addAttribute("listBooks", result);
        return "index";

    }

    @GetMapping("/book/{id}")
    public String showBookDetails(@PathVariable("id") Long id, Model model) {
        Book book = bookService.getBookById(id);
        if (book == null) {
            return "redirect:/";
        }
        model.addAttribute("book", book);
        return "book_details";
    }

}


