DROP TABLE IF EXISTS book;

CREATE TABLE book (

    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(100),
    description TEXT,
    image_url VARCHAR(500)
);

